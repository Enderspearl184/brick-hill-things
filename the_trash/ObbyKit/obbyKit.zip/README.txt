The maptools.brk file contains the types of bricks that I already scripted so you can play around with them. Here's how to use the types of bricks.

to make a kill brick the brick name must start with "kill" (case sensitive) but can have anything after that. (so copying kill bricks will work.)
to make a checkpoint, name the brick "Checkpoint(checkpointnumber)" with (checkpointnumber) being what number checkpoint it should be. Checkpoints only count if the number is 1 higher than the player's current checkpoint.
make sure that Checkpoint1 is a spawnpoint!
to make teleporters, name one brick "tpfrom(number)" and another "tpto(thesamenumber)" and when players touch the tpfrom brick they will be teleported to the tpto brick. NOTE: each set of teleporters needs a different number or it won't work properly.


and remember... fix your lighting.