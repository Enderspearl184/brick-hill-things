const checkpointcount = world.bricks.filter((b)=>b.name.startsWith('Checkpoint')).length
world.bricks.forEach((b) => {
	if (b.name.startsWith("Checkpoint")) {
		b.checkpoint = parseInt(b.name.replace("Checkpoint", ""))
		b.touching((p) => {
			if (p.checkpoint+1==b.checkpoint) {
				p.checkpoint=b.checkpoint
				p.topPrint(`Checkpoint: ${p.checkpoint}/${checkpointcount}`, 100000)
				p.setScore(p.checkpoint)
				p.message("You reached a new checkpoint!")
				p.CheckPointPos=new Vector3(b.position.x+(b.scale.x/2),b.position.y+(b.scale.x/2),b.position.z+b.scale.z+1)
			}
		})
	}
})

Game.on("playerJoin", (p) => {
	p.checkpoint=1
	p.on("respawn", () => {			
		p.topPrint(`Checkpoint: ${p.checkpoint}/${checkpointcount}`, 100000)
		if (p.checkpoint!==1){
			p.setPosition(p.CheckPointPos)
		}
	})
	p.on("initialSpawn", () => {
		p.topPrint(`Checkpoint: 1/${checkpointcount}`, 100000)
		p.setScore(1)
	})
})